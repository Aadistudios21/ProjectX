import './App.css';
import Saler from './Saler'

function App() {
  return (
    <div className="App">
      <Saler></Saler>
    </div>
  );
}

export default App;
